/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controlador;

import InterfaceRepositorio.Interface;
import Negocio.Aluno;
import Negocio.CClasses;
import Repositorio.RepositorioAluno;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Rodrigo-Casa
 */
@ManagedBean(name = "controlAluno")
@SessionScoped
public class ControladorAluno {
    
    private RepositorioAluno ra= null;
    private Aluno Selectalu = null;

    
    public Aluno getSelectalu(){
    return Selectalu;
    }
    
    public void setSelectalu(Aluno Selectalu) {
        this.Selectalu = Selectalu;
    }
    
    public ControladorAluno(){
        this.ra = new RepositorioAluno();
    }

    
  
      
    public String inserirAluno(Aluno a){
         this.ra.inserir(a);
         return "index.xhtml";
    }
     public void alterarAluno(Aluno a){
        this.ra.alterar(a);
    }
   
    public Aluno recuperarAluno(String matricula){
        return this.ra.recuperar(matricula);
    }
    
    public void deletarAluno(Aluno a){
        this.ra.deletar(a);
    }
    
    public List<Aluno> recuperarTodosAlunos(){
        return this.ra.recuperarTodos();
    }
    public List<CClasses> recuperarRelatorios(){
        return this.Selectalu.getRelatorios();
    }

   
    
    
}
