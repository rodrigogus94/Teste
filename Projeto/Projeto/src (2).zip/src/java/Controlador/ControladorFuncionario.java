/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controlador;

import Negocio.Funcionario;
import Repositorio.RepositorioFucionario;
import java.io.IOException;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import org.apache.commons.codec.digest.DigestUtils;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Rodrigo-Casa
 */
@ManagedBean (name = "ControladorFuncio")
@SessionScoped
public class ControladorFuncionario {
    
    private RepositorioFucionario rf = null;
    private Funcionario selectFun = null;

    public ControladorFuncionario() {
        this.rf = new RepositorioFucionario();
    }

    public Funcionario getSelectFun() {
        return selectFun;
    }

    public void setSelectFun(Funcionario selectFun) {
        this.selectFun = selectFun;
    }
    
    public String inserirFuncionario(Funcionario f){
         this.rf.inserir(f);
         return "index.xhtml";
    }
     public void alterarFuncionario(Funcionario f){
        this.rf.alterar(f);
    }
   
    public Funcionario recuperarFuncionario(String codigo){
        return this.rf.recuperar(codigo);
    }
    
    public void deletarFuncionario(Funcionario f){
        this.rf.deletar(f);
    }
    
    public List<Funcionario> recuperarTodosFuncionario(){
        return this.rf.recuperarTodos();
    }

  

}
