/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Repositorio;

import InterfaceRepositorio.Interface;
import Negocio.Funcionario;
import dao.DaoManagerHiber;
import java.util.List;
import org.apache.commons.codec.digest.DigestUtils;

/**
 *
 * @author Rodrigo-Casa
 */
public class RepositorioFucionario implements Interface<Funcionario, String>{

    @Override
    public void inserir(Funcionario t) {
        t.setSenha(DigestUtils.md5Hex(t.getSenha()));
        dao.DaoManagerHiber.persist(t);
    }

    @Override
    public void alterar(Funcionario t) {
        dao.DaoManagerHiber.update(t);
    }

    @Override
    public Funcionario recuperar(String g) {
      return  (Funcionario)dao.DaoManagerHiber.recover("from Funcionario="+g).get(0);
    }

    @Override
    public void deletar(Funcionario t) {
        dao.DaoManagerHiber.delete(t);
    }

    @Override
    public List<Funcionario> recuperarTodos() {
        return dao.DaoManagerHiber.recover("select funcionario.nome, funcionario.siape from Funcionario funcionario");
    }

    public Funcionario recuperarPorLogin(String siape, String senha) {
        return (Funcionario)dao.DaoManagerHiber.recover("from Funcionario where siape = " + "and senha = " + senha);
    }
    
}
